the regular expression with sed.

sed 's/\b\([a-z]\+\)[ ,\n]\1/\1/g'

Try to match as much as possible. "[a-z]*" matches zero or more lower case letters, and tries to match as many characters as possible.

The "\1" doesn't have to be in the replacement string (in the right hand side). It can be in the pattern you are searching for (in the left hand side). If you want to eliminate duplicated words, you can try

sed 's/\([a-z]*\) \1/\1/'

the regex memory 1 will have line (line followed by a space) in it and you are searching for its repetition. Since there is not space after the last line the match fails.

To fix this add a space after the ending word line

Alternatively you can change the regex to:


sed -e 's/\b\([a-z]\+\)[ ,\n]\1/\1/g'

ref: https://www.grymoire.com/Unix/Regular.html 
     https://www.grymoire.com/Unix/Sed.html

