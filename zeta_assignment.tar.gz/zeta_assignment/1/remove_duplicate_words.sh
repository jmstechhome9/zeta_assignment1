#!/bin/sh
sed 's/\b\([a-z]\+\)[ ,\n]\1/\1/g'
