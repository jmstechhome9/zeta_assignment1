install docker and docker-compose in your isntance
ref the below links to setup docker and docker-compose

https://docs.docker.com/engine/install/#server
https://docs.docker.com/engine/install/ubuntu/    (if its ubuntu)
https://docs.docker.com/compose/install/          (install docker-compose)

If you would like to use Docker as a non-root user, you should now consider adding your user to the “docker” group with something like:

  sudo usermod -aG docker <your-user>

  start the docker service

  #sudo  systemctl start docker 
then exit current console then login new session of console

then build docker image with docker compose

# cd zeta_assignment/3/api && docker-compose build

then run the containers

#cd zeta_assignment/3/api &&  docker-compose up -d

it will run two application one redis and another one python autocomplete app

then open the browser access teh app http://<pubipaddr/pubdomain>:5000

then access the /add_word endpoint to add the data

ex:

http://<pubipaddr/pubdomain>:5000/add_word?word=foo
/add_word?word=football
/add_word?word=foot
/add_word?word=foobar

then access the /autocomplete endpoint to get the autocomplete data 

/autocomplete?query=fo

you can see the output like below

[
  "foo", 
  "foobar", 
  "foot", 
  "football"
]

Note: allow the 5000 port in security group/ firewalls




